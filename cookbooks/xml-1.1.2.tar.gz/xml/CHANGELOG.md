## v1.1.2:

* [COOK-2059] - missing dependency on build-essential

## v1.1.0:

* [COOK-1826] - support nokogiri chef_gem
* [COOK-1902] - add support for archlinux

## v1.0.4:

* [COOK-1232] - add xslt to xml cookbook

## v1.0.2:

* [COOK-953] - Add FreeBSD support
* [COOK-775] - Add Amazon Linux support

